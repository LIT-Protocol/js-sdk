# getlit-sdk

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build getlit-sdk` to build the library.

## Running unit tests

Run `nx test getlit-sdk` to execute the unit tests via [Jest](https://jestjs.io).

# Notes to be organised

- If you are using next.js, you will need to enable `SPA` via `"use client";` 